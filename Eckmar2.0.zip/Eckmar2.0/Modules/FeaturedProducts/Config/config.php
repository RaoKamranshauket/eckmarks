<?php

return [
    'name' => 'FeaturedProducts'
];
