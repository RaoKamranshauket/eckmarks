
# Requirements
Everything required for Marketplace to run normally

## PHP Extensions
-  sodium   (Message encryptuon)
-  gmp (Precision calculation)
-  xmlrpc (Bitmessage communication protocol)
## Additional services
- Bitcoind (Processing transactions)
- Elasticsearch (Searching trough records)
