<?php


namespace App\Console\Utility;


class CommandSignature
{
    public static function get(): string {
        return "";
    }
}