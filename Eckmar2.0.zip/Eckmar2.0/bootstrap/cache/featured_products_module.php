<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FeaturedProducts\\Providers\\FeaturedProductsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FeaturedProducts\\Providers\\FeaturedProductsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);