<?php $__env->startSection('title','Home Page'); ?>

<?php $__env->startSection('content'); ?>

    

    <div class="row">
        <div class="col-md-3 col-sm-12" style="margin-top:2.3em">
            <?php echo $__env->make('includes.categories', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="row mt-3">
                <div class="col">
                    <div class="card ">
                        <div class="card-header">
                            Official Link Mirrors
                        </div>
                        <div class="card-body text-center">
                            <?php $__currentLoopData = config('marketplace.mirrors'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mirror): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($mirror); ?>" style="text-decoration:none;"><?php echo e($mirror); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-12 mt-3 ">

            <div class="row">
                <div class="col">
                    <h1 class="col-10">Welcome to <?php echo e(config('app.name')); ?></h1>
                    <hr>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam, aliquid cupiditate dolore enim et
                    eveniet fugiat illum ipsum itaque minus molestias nihil optio porro quisquam quo saepe sunt velit
                    veritatis.
                </div>
            </div>
            <div class="row mt-5">

                <div class="col-md-4">
                    <h4><i class="fa fa-money-bill-wave-alt text-info"></i> No deposit</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aliquid dolorem hic nisi
                        ratione repellendus suscipit totam vitae!
                    </p>
                </div>

                <div class="col-md-4">
                    <h4><i class="fa fa-shield-alt text-info"></i> Escrow</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aliquid dolorem hic nisi
                        ratione repellendus suscipit totam vitae!
                    </p>
                </div>

                <div class="col-md-4">
                    <h4><i class="fa fa-coins text-info"></i> Multiple-Coins</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aliquid dolorem hic nisi
                        ratione repellendus suscipit totam vitae!
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <hr>
                </div>
            </div>
            <?php if (\Illuminate\Support\Facades\Blade::check('isModuleEnabled', 'FeaturedProducts')): ?>
                <?php echo $__env->make('featuredproducts::frontpagedisplay', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>

            <div class="row mt-4">

                <div class="col-md-4">
                    <h4>
                        Top Vendors
                    </h4>
                    <hr>
                    <?php $__currentLoopData = \App\Vendor::topVendors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <table class="table table-borderless table-hover">
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('vendor.show',$vendor)); ?>"
                                       style="text-decoration: none; color:#212529"><?php echo e($vendor->user->username); ?></a>
                                </td>
                                <td class="text-right">
                                    <span class="btn btn-sm <?php if($vendor->vendor->experience >= 0): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?> active"
                                          style="cursor:default">Level <?php echo e($vendor->getLevel()); ?></span>

                                </td>
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4">
                    <h4>
                        Latest orders
                    </h4>
                    <hr>
                    <?php $__currentLoopData = \App\Purchase::latestOrders(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <table class="table table-borderless table-hover">
                            <tr>
                                <td>
                                    <img class="img-fluid" height="23px" width="23px"
                                         src="<?php echo e(asset('storage/'  . $order->offer->product->frontImage()->image)); ?>"
                                         alt="<?php echo e($order->offer->product->name); ?>">
                                </td>
                                <td>
                                    <?php echo e(str_limit($order->offer->product->name,50,'...')); ?>

                                </td>
                                <td class="text-right">
                                    <?php echo e($order->getSumLocalCurrency()); ?> <?php echo e($order->getLocalSymbol()); ?>

                                </td>
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-md-4">
                    <h4>
                        Rising vendors
                    </h4>
                    <hr>
                    <?php $__currentLoopData = \App\Vendor::risingVendors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <table class="table table-borderless table-hover">
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('vendor.show',$vendor)); ?>"
                                       style="text-decoration: none; color:#212529"><?php echo e($vendor->user->username); ?></a>
                                </td>
                                <td class="text-right">
                                    <span class="btn btn-sm <?php if($vendor->vendor->experience >= 0): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?> active"
                                          style="cursor:default">Level <?php echo e($vendor->getLevel()); ?></span>
                                </td>
                            </tr>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


            </div>


        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>