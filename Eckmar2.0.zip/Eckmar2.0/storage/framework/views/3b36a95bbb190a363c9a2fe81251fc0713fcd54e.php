<div class="row my-2">

    <div class="col-md-3 col-sm-4 col-12">
        <img class="rounded img-thumbnail mw-100" src="<?php echo e(asset('storage/'  . $product -> frontImage() -> image)); ?>"
             alt="<?php echo e($product -> name); ?>">
    </div>

    <div class="col-md-9 col-sm-8 col-12">
        <div class="row pb-2 mb-2 border-bottom border-light">
            <div class="col-md-8">
                <a href="<?php echo e(route('product.show', $product)); ?>"><h3 class="mb-0"><?php echo e($product -> name); ?></h3></a>
            </div>
            <div class="col-md-4">
                <h5 class="mb-0 text-right">Posted by <a href="<?php echo e(route('vendor.show', $product -> user)); ?>"
                                             class="badge badge-info"><?php echo e($product -> user -> username); ?></a></h5>
            </div>
        </div>

        <div class="row">
            <div class="col-md-7">
                From: <strong><?php echo $__env->make('includes.currency', ['usdValue' => $product -> price_from ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></strong>
                <br>
                <span class="mr-2">Category:</span>
                <?php $__currentLoopData = $product -> category -> parents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ancestor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('category.show', $ancestor)); ?>"><?php echo e($ancestor -> name); ?></a>
                    <i class="fas fa-chevron-right"></i>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('category.show', $product -> category)); ?>"><?php echo e($product -> category -> name); ?></a>
                <br>
                <span class="badge badge-info"><?php echo e(ucfirst($product -> type)); ?></span> type
                <br>
                <strong><?php echo e($product -> quantity); ?></strong> left / <strong><?php echo e($product -> orders); ?></strong>
                sold
            </div>

            <div class="col-md-5">
                <p class="text-muted">
                    <?php echo e($product -> short_description); ?>

                </p>
                <p>
                    Payment coins:
                    <?php $__currentLoopData = $product -> getCoins(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-info"><?php echo e(strtoupper(\App\Purchase::coinDisplayName($coin))); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <a href="<?php echo e(route('product.show', $product)); ?>" class="btn btn-primary d-block">
                    <i class="fas fa-shopping-cart mr-2"></i>
                    Buy now
                </a>
            </div>

        </div>

    </div>

    <div class="card-body">
        <p class="card-subtitle"></p>
        <p class="card-text">
        </p>
    </div>


</div>