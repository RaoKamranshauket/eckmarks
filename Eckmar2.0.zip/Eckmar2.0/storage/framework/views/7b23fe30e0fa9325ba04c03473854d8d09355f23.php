<?php $__env->startSection('admin-content'); ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('isModuleEnabled', 'FeaturedProducts')): ?>
        <?php echo $__env->make('featuredproducts::featuredproductsview', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>