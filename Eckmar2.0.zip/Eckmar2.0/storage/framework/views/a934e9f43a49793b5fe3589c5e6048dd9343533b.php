<div class="form-group  mt-3">
    <div class="text-center">
        <img src="<?php echo e($captcha); ?>" alt="">
    </div>
    <input class="form-control mt-3 <?php if($errors->has('captcha')): ?> is-invalid <?php endif; ?>" type="text" name="captcha" placeholder="Enter Captcha">
    <?php if (\Illuminate\Support\Facades\Blade::check('error', 'captcha',$errors)): ?>
    <p class="text-danger"><?php echo e($errors->first('captcha')); ?></p>
    <?php endif; ?>

</div>