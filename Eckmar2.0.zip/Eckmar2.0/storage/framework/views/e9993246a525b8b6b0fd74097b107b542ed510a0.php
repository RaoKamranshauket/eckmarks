<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                List of Vendor Purchases
            </h4>
            <hr>
        </div>
    </div>



    <table class="table">
        <thead>
        <tr>
            <th>Vendor</th>
            <th>
                <div class="row">
                    <div class="col-md-1">
                        Coin
                    </div>
                    <div class="col-md-3">
                        Amount
                    </div>
                    <div class="col-md-4">
                        Address
                    </div>
                    <div class="col-md-4">
                        Paid at
                    </div>
                </div>
            </th>
        </tr>
        </thead>
        <tbody>
        
            <?php if($vendors->count() == 0 ): ?>
                <tr>
                    <td colspan="4" class="text-center">
                        <h4 class="mt-5">No Vendor purchases found found</h4>
                    </td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <strong><?php echo e($vendor->user->username); ?></strong>
                        </td>
                        <td>
                            <table class="table table-borderless">
                                <?php $__currentLoopData = $vendor->user->vendorPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorPurchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($vendorPurchase->amount > 0): ?>
                                        <div class="row my-1">
                                            <div class="col-md-1">
                                                <span class="badge badge-info">
                                                    <?php echo e(strtoupper($vendorPurchase -> coin)); ?>

                                                </span>
                                            </div>
                                            <div class="col-md-3">
                                                <span class="badge badge-primary">
                                                    <?php echo e($vendorPurchase -> amount); ?>

                                                </span>
                                            </div>
                                            <div class="col-md-4">
                                                <input class="form-control form-control-sm" readonly="readonly" value="<?php echo e($vendorPurchase -> address); ?>"/>
                                            </div>
                                            <div class="col-md-4 text-muted">
                                                <?php echo e($vendorPurchase -> updated_at -> diffForHumans()); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>


                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($vendors->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>