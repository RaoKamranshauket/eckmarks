<div class="row mt-1 mb-2">
    <div class="col">
        <h4>Featured Products</h4>
    </div>
</div>
<div class="row">
    <?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 my-md-0 my-2 col-12">
            <?php echo $__env->make('includes.product.card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>