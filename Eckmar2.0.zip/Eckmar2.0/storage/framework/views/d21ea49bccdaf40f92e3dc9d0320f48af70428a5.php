<?php $__env->startSection('title','Product - ' . $product -> name ); ?>

<?php $__env->startSection('content'); ?>


    <nav class="main-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home')); ?>">Products</a>
            </li>
            <?php $__currentLoopData = $product -> category -> parents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ancestor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item" aria-current="page"><a
                            href="<?php echo e(route('category.show', $ancestor)); ?>"><?php echo e($ancestor -> name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="breadcrumb-item active" aria-current="page"><a
                        href="<?php echo e(route('category.show', $product -> category)); ?>"><?php echo e($product -> category -> name); ?></a>
            </li>
        </ol>
    </nav>


    <div class="row">
        <div class="col-md-4">
            <div class="slider">
                <div class="slides">
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $product -> images() -> orderBy('first', 'desc') -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="slide-<?php echo e($i++); ?>">
                            <img src="<?php echo e(asset('storage/' . $image -> image)); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php $i = 1; ?>
                <?php $__currentLoopData = $product -> images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#slide-<?php echo e($i); ?>"><?php echo e($i++); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="col-md-5">
            <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <h2><?php echo e($product -> name); ?></h2>
            <hr>

            <div class="row">
                <div class="col-md-12 text-center">

                    <form action="<?php echo e(route('profile.cart.add', $product)); ?>"  method="POST">
                        <?php echo e(csrf_field()); ?>


                    <table class="table border-0 text-left table-borderless">
                        <tbody>

                        <tr>
                            <td class="text-right text-muted">Quality rate:</td>
                            <td>
                                <?php echo $__env->make('includes.purchases.stars', ['stars' => (int)$product->avgRate('quality_rate')], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-right text-muted">
                                Type
                            </td>
                            <td>
                                <strong class="badge badge-info"><?php echo e(ucfirst($product -> type)); ?></strong>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-right text-muted">
                                Offers
                            </td>
                            <td>
                                <ul>
                                    <?php $__currentLoopData = $product -> offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <strong><?php echo $__env->make('includes.currency', ['usdValue' => $offer -> dollars], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></strong> per <?php echo e(str_plural($product -> mesure, 1)); ?>,
                                            for at least <?php echo e($offer -> min_quantity); ?> <?php echo e(str_plural('product', $offer -> min_quantity)); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </td>
                        </tr>
                        <tr>
                            <td class="text-right text-muted">
                                Coins
                            </td>
                            <td>
                                <?php $__currentLoopData = $product -> getCoins(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-indigo"><?php echo e(strtoupper(\App\Purchase::coinDisplayName($coin))); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-right text-muted">Left/Sold</td>
                            <td>
                                <span class="badge badge-light"><?php echo e($product -> quantity); ?> <?php echo e(str_plural($product -> mesure, $product -> quantity)); ?></span>/
                                <span class="badge badge-light"><?php echo e($product -> numberOfPurchases()); ?> <?php echo e(str_plural($product -> mesure, $product -> orders)); ?> </span>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <?php if($product->user->vendor->experience < 0): ?>
                                    <p class="text-danger border border-danger rounded p-1 mt-2"><span
                                                class="fas fa-exclamation-circle"></span> Negative experience, trade with caution !
                                    </p>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <?php if($product -> isPhysical()): ?>
                                <td class="text-muted text-right">
                                    <label for="delivery">Delivery method:</label>
                                </td>
                                <td>
                                    <select name="delivery" id="delivery"
                                            class="form-control form-control-sm <?php if($errors -> has('delivery')): ?> is-invalid <?php endif; ?>">
                                        <?php $__currentLoopData = $product -> specificProduct() -> shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($shipping -> id); ?>"><?php echo e($shipping -> long_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                            <?php endif; ?>
                        </tr>

                        <tr class="bg-light">
                            <td class="text-right text-muted">
                                <label for="coin">Pay with Coin:</label>
                            </td>
                            <td>
                                <?php if(count($product -> getCoins()) > 1): ?>
                                    <select name="coin" id="coin" class="form-control form-control-sm">
                                        <?php $__currentLoopData = $product -> getCoins(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($coin); ?>"><?php echo e(strtoupper(\App\Purchase::coinDisplayName($coin))); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php elseif(count($product -> getCoins()) == 1): ?>
                                    <span class="badge badge-mblue"><?php echo e(strtoupper(\App\Purchase::coinDisplayName($product -> getCoins()[0]))); ?></span>
                                    <input type="hidden" name="coin" value="<?php echo e($product -> getCoins()[0]); ?>">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr class="bg-light">
                            <td class="text-right text-muted">
                                <label for="type">Purchase type:</label>
                            </td>
                            <td>
                                <?php if(count($product -> getTypes()) > 1): ?>
                                    <select name="type" id="type" class="form-control form-control-sm">
                                        <?php $__currentLoopData = $product -> getTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type); ?>"><?php echo e(\App\Purchase::$types[$type]); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php elseif(count($product -> getTypes()) == 1): ?>
                                    <span class="badge badge-mblue"><?php echo e(\App\Purchase::$types[$product -> getTypes()[0]]); ?></span>
                                    <input type="hidden" name="type" value="<?php echo e($product -> getTypes()[0]); ?>">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr class="bg-light">

                            <td class="text-right text-muted">
                                <label for="amount">Amount:</label>
                            </td>
                            <td class="row">
                                <div class="col-md-5">
                                    <input type="number" min="1" name="amount" id="amount"
                                           value="1"
                                           max="<?php echo e($product -> quantity); ?>"
                                           class="<?php if($errors -> has('amount')): ?> is-invalid <?php endif; ?> form-control form-control-sm"
                                           placeholder="Amount of <?php echo e(str_plural($product -> mesure)); ?>"/>
                                </div>
                                <div class="col-md-7">
                                    <button class="btn btn-sm btn-block mb-2 btn-primary"><i class="fas fa-plus mr-2"></i>Add to
                                        cart
                                    </button>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(auth() -> user() -> isWhishing($product)): ?>
                                            <a href="<?php echo e(route('profile.wishlist.add', $product)); ?>"
                                               class="btn btn-outline-secondary btn-block btn-sm"><i class="far fa-heart"></i> Remove
                                                from
                                                wishlist</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('profile.wishlist.add', $product)); ?>"
                                               class="btn btn-sm btn-block btn-outline-danger"><i
                                                        class="fas fa-heart"></i> Add to wishlist</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>

                        </tbody>
                    </table>

                    </form>
                        <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>


            </div>
        </div>

        
        <div class="col-md-3">
            <div class="card mb-2">
                <div class="card-body">
                    <h6>
                        <i class="fas fa-shield-alt"></i>
                        Shop with confidence
                    </h6>
                    <div class="text-muted">
                        You are Escrow protected for each product in the market!
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    Seller information
                </div>
                <div class="card-body">
                    <div class="btn-group">
                        <a class="btn btn-light btn-sm" href="<?php echo e(route('vendor.show', $product -> user)); ?>">
                            <span ><?php echo e($product -> user -> username); ?></span></a>

                        <span class="btn btn-primary active btn-sm">Level <?php echo e($product->user->vendor->getLevel()); ?></span>
                    </div>

                    <?php
                    $vendor = $product->user;
                    ?>
                    <div class="row my-1 text-md-center">
                        <div class="col-4">
                            <span class="fas fa-plus-circle text-success"></span> <?php echo e($vendor->vendor->countFeedbackByType('positive')); ?>

                        </div>
                        <div class="col-4">
                            <span class="fas fa-stop-circle text-secondary"></span> <?php echo e($vendor->vendor->countFeedbackByType('neutral')); ?>


                        </div>
                        <div class="col-4">
                            <span class="fas fa-minus-circle text-danger"></span> <?php echo e($vendor->vendor->countFeedbackByType('negative')); ?>

                        </div>
                    </div>
                    <hr>
                        <a href="<?php echo e(route('profile.messages').'?otherParty='.$product -> user ->username); ?>" class="btn mb-1 btn-outline-secondary"><span class="fas fa-envelope"></span> Send message</a>
                        <a href="<?php echo e(route('search',['user'=>$product->user->username])); ?>"  class="btn mb-1 btn-outline-info">Seller's products (<?php echo e($product -> user ->products()->count()); ?>)</a>

                </div>
            </div>
        </div>

    </div>

    
    <ul id="productsmenu" class="my-4 nav nav-tabs nav-fill">
        <li class="nav-item">
            <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'product.show')): ?> active <?php endif; ?>"
               href="<?php echo e(route('product.show', $product)); ?>#productsmenu">Details</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'product.rules')): ?> active <?php endif; ?>"
               href="<?php echo e(route('product.rules', $product)); ?>#productsmenu">Payment rules</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'product.feedback')): ?> active <?php endif; ?>"
               href="<?php echo e(route('product.feedback', $product)); ?>#productsmenu">Feedback</a>
        </li>
        <?php if($product -> isPhysical()): ?>
            <li class="nav-item">
                <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'product.delivery')): ?> active <?php endif; ?>"
                   href="<?php echo e(route('product.delivery', $product)); ?>#productsmenu">Delivery</a>
            </li>
        <?php endif; ?>


    </ul>

    <?php echo $__env->yieldContent('product-content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>