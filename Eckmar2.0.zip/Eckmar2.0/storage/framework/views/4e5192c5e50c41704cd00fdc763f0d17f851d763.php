<?php $__env->startSection('form-content'); ?>
    <h3>Add digital content</h3>
    <hr>
    <form method="POST" action="<?php echo e(route('profile.vendor.product.digital.post', $digitalProduct)); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label for="product_content">Product's content:</label>
            <textarea name="product_content" id="product_content"
                      class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'content', $errors)): ?> is-invalid <?php endif; ?>" rows="5"
                      placeholder="Details about the product"><?php echo e($digitalProduct -> content); ?></textarea>
            <p class="text-muted">Leave blank, if digital content doesn't have automatic delivery. Otherwise each
                product put in separated lines!</p>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'product_content', $errors)): ?>
            <div class="invalid-feedback d-block text-center">
                <?php echo e($errors -> first('product_content')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-check mx-2 mb-2 ">
            <input class="form-check-input" type="checkbox" value="1" name="autodelivery"
                   id="autodelivery" <?php echo e($digitalProduct -> autodelivery == true ? 'checked' : ''); ?>>
            <label class="form-check-label" for="autodelivery">
                Automatic delivery
            </label>
            <p class="text-muted">If it is checked, quantity of this product will be number of lines in product content.</p>
        </div>


        <div class="form-row justify-content-center">
            <div class="form-group col-md-3 text-center">
                <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                    <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                    <a href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'images'])); ?>"
                       class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
                <?php elseif(request() -> is('admin/product/*')): ?>
                    <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                    <a href="<?php echo e(route('admin.product.edit', [$basicProduct, 'images'])); ?>"
                       class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
                <?php else: ?>
                    <button class="btn btn-outline-primary" type="submit"><i class="fas fa-chevron-down mr-2"></i> Next
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.profile.addingform', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>