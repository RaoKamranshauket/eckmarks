<?php if(request() -> is('profile/vendor/product/edit/*')): ?>
    <?php $__env->startSection('product-title', 'Edit product - '. $basicProduct -> name); ?>
<?php else: ?>
    <?php $__env->startSection('product-title', 'Add ' . session('product_type') . ' product'); ?>
<?php endif; ?>

<?php $__env->startSection('product-images-form'); ?>
    <?php echo $__env->make('includes.profile.imagesform', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.productadding', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>