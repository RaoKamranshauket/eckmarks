<h4>Categories</h4>
<hr>
<div class="list-group categories">
    <?php echo $__env->make('includes.subcategories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>