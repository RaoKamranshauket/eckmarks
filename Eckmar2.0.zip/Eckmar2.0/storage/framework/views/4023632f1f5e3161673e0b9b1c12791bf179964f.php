<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.index')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.index')); ?>">
        <i class="fas fa-columns mr-2"></i>
        Index
    </a>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'categories')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.categories')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.categories')); ?>">
        <i class="fas fa-list mr-2"></i>
        Categories
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'messages')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.messages.mass')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.messages.mass')); ?>">
        <i class="fas fa-envelope mr-2"></i>
        Mass Messages
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'users')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.users')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.users')); ?>">
        <i class="fas fa-users mr-2"></i>
        Users
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'products')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.product')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.products')); ?>">
        <i class="fas fa-shopping-bag mr-2"></i>
        Products
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'products')): ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('isModuleEnabled', 'FeaturedProducts')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.featuredproducts')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.featuredproducts.show')); ?>">
        <i class="fas fa-medal mr-2"></i>
        Featured Products
    </a>
    <?php endif; ?>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'purchases')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.purchases')): ?> active <?php endif; ?> <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.purchase')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.purchases')); ?>">
        <i class="fas fa-shopping-cart mr-2"></i>
        Purchases
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'logs')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.log')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.log')); ?>">
        <i class="fas fa-list-alt mr-2"></i>
        Log
    </a>
    <?php endif; ?>

    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.bitmessage')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.bitmessage')); ?>">
        <i class="fas fa-envelope-open mr-2"></i>
        Bitmessage
    </a>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'disputes')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.disputes')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.disputes')); ?>">
        <i class="fas fa-exclamation-triangle mr-2"></i>
        Disputes
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'tickets')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.tickets')): ?> active <?php endif; ?> <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.tickets')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.tickets')); ?>">
        <i class="far mr-2 fa-question-circle"></i>
        Tickets
    </a>
    <?php endif; ?>

    <?php if (\Illuminate\Support\Facades\Blade::check('hasAccess', 'vendorpurchase')): ?>
    <a class="nav-link <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.vendor.purchases')): ?> active <?php endif; ?> <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin.vendor.purchases')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.vendor.purchases')); ?>">
        <i class="far mr-2 fa-list-alt"></i>
        Vendor Purchases
    </a>
    <?php endif; ?>

</div>