<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                List of all Purchases
            </h4>
            <hr>
        </div>
    </div>


    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Buyer</th>
            <th>Vendor</th>
            <th>Total</th>
            <th>Time</th>
        </tr>
        </thead>
        <tbody>

            <?php if($purchases->count() == 0 ): ?>
                <tr>
                    <td colspan="6" class="text-center">
                        <h4 class="mt-5">No products found</h4>
                    </td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('admin.purchase', $purchase)); ?>" class="btn btn-sm btn-mblue mt-1"><?php echo e($purchase -> short_id); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('product.show', $purchase -> offer -> product)); ?>"><?php echo e($purchase -> offer -> product -> name); ?></a>
                        </td>
                        <td>
                            <?php echo e($purchase->quantity); ?>

                        </td>
                        <td>
                            <span class="badge badge-info"><?php echo e($purchase->buyer->username); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.users.view',['user'=>$purchase->vendor->user->id])); ?>" class="badge badge-primary"><?php echo e($purchase->vendor->user->username); ?></a>
                        </td>
                        <td>
                            <?php echo $__env->make('includes.currency', ['usdValue' => $purchase -> value_sum], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </td>
                        <td>
                            <?php echo e($purchase -> created_at -> diffForHumans()); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($purchases->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>