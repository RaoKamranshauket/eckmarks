<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.validation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <h1 class="my-3">Decrypt messages</h1>
    <hr>
    <div class="row justify-content-center">
       <div class="col-md-12">
           <p>All your messages are encrypted. Please enter your password to unlock your decryption key and make messages viewable.</p>
       </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="<?php echo e(route('profile.messages.decrypt.post')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="password" name="password" class="form-control" >
                </div>
                <div class="form-group text-center">
                    <button class="btn  btn-outline-success" type="submit">Decrypt messages</button>
                </div>
            </form>
        </div>


    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>