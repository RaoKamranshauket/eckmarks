<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h2 class="mb-3">Checkout (<?php echo e($numberOfItems); ?>)</h2>

            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>#</th>
                        <th>Price</th>
                        <th>Paying with</th>
                        <th>Payment type & Shipping</th>
                        <th>Total</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('product.show', $productId)); ?>"><?php echo e($item -> offer -> product -> name); ?></a>
                            </td>
                            <td class="text-center">
                                <?php echo e($item -> quantity); ?>

                            </td>
                            <td class="text-center">
                                <span class="badge badge-mblue">
                                    <?php echo $__env->make('includes.currency', ['usdValue' => $item -> offer -> price], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-info"><?php echo e(strtoupper(\App\Purchase::coinDisplayName($item -> coin_name))); ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-primary"><?php echo e(\App\Purchase::$types[$item->type]); ?></span>

                                <?php if($item -> shipping): ?>
                                    <?php echo e($item -> shipping -> name); ?> -
                                    <?php echo $__env->make('includes.currency', ['usdValue' => $item -> shipping -> price], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php else: ?>
                                    <span class="badge badge-info">Digital delivery</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-mblue">
                                    <?php echo $__env->make('includes.currency', ['usdValue' => $item -> value_sum], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </span>
                            </td>
                            <td>
                                <?php if($item -> message): ?>
                                    <?php if(\App\Message::messageEncrypted($item -> message)): ?>
                                        <textarea class="form-control"  readonly rows="5"><?php echo e($item -> message); ?></textarea>
                                    <?php else: ?>
                                        <p class="text-muted">
                                            <?php echo e($item -> message); ?>

                                        </p>

                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge badge-info">No message</span>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <div class="col-md-4">
            <a href="<?php echo e(route('profile.cart')); ?>" class="btn btn-lg btn-danger">
                <i class="fas fa-chevron-left mr-2"></i>
                Back to cart
            </a>
        </div>
        <div class="col-md-8 text-right">
            <h3 class="text-right d-inline-block mr-2">Total: <?php echo $__env->make('includes.currency', ['usdValue' => $totalSum], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></h3>
        </div>
        
            
                
                
                    
                    
                
            
        
        <div class="col-md-12 mt-3 justify-content-end text-right">
            <form action="<?php echo e(route('profile.cart.make.purchases')); ?>">
                
                <button type="submit"  class="btn btn-mblue btn-lg">
                    <i class="fas fa-shopping-cart mr-2"></i>
                    Purchase
                </button>
            </form>
        </div>


    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>