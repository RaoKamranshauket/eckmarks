<div class="card mt-5 profile-card border border-secondary" >
    <div class="card-body">

        <div class="row">
            <div class="col-sm-3">
                <h4><a href="<?php echo e(route('vendor.show', $vendor)); ?>" style="color: black"><?php echo e($vendor -> username); ?></a></h4>
                <p> <span class="btn <?php if($vendor->vendor->experience >= 0): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?> active" style="cursor:default">Level <?php echo e($vendor->vendor->getLevel()); ?></span>
                    <span class="<?php if($vendor->vendor->experience < 0): ?> text-danger <?php endif; ?>">(<?php echo e($vendor->vendor->getShortXP()); ?> XP)</span></p>
                <?php if($vendor->vendor->isTrusted()): ?>
                    <p class="badge badge-success">Trusted vendor <span class="fa fa-check-circle"></span></p>
                <?php endif; ?>
                <?php if($vendor->vendor->isDwc()): ?>
                    <p class="badge badge-danger">Deal with caution <span class="fa fa-exclamation-circle"></span></p>
                <?php endif; ?>
            </div>
            <div class="col-sm-5 text-center">
                <p>
                    <?php echo e($vendor->vendor->about); ?>

                </p>
            </div>
            <div class="col-sm-4 text-right">
                <p>
                    <a href="<?php echo e(route('profile.messages').'?otherParty='.$vendor->username); ?>" class="btn btn-outline-secondary"><span class="fas fa-envelope"></span> Send message</a></p>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <?php echo $__env->make('includes.vendor.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

    </div>
</div>