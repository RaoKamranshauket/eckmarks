<?php $__env->startSection('title','Home Page'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3">
            <?php echo $__env->make('includes.detailedsearch', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-6">
                    <h4 class="float-left">Search results for "<?php echo e($query); ?>" <?php if(request('user')): ?> by user <?php echo e(request('user')); ?> <?php endif; ?></h4>
                </div>
                <div class="col-5">
                    <p class="float-right text-secondary small mt-2 ">
                        Fetched <?php echo e($results_count); ?> <?php echo e(str_plural('result',$products->count())); ?>

                        in <?php echo e($time); ?> <?php echo e(str_plural('second',$time)); ?></p>
                </div>
                <div class="col-md-1">
                    <?php echo $__env->make('includes.viewpicker', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <hr>
                </div>
            </div>
            <?php if($products->count() == 0): ?>
                <h4>
                    Couln't find any results for that query, try searching for something else
                </h4>
            <?php else: ?>
                <?php if($productsView == 'list'): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('includes.product.row', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mt-3">
                            <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 my-md-0 my-2 col-12">
                                    <?php echo $__env->make('includes.product.card', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            <?php endif; ?>

            <div class="mt-4">
                <?php echo e($products -> links('includes.paginate')); ?>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>