<ul>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('admin.categories.show', $category -> id)); ?>"><?php echo e($category -> name); ?></a>
            <a class="btn btn-outline-danger btn-sm" href="<?php echo e(route('admin.categories.delete', $category -> id)); ?>">Delete</a>
            <?php if($category -> children -> isNotEmpty()): ?>
                <ul class="m-0 p-0">
                    <?php echo $__env->make('includes.admin.listcategories', ['categories' => $category -> children], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </ul>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>