<?php $__env->startSection('title', 'Purchases'); ?>

<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1 class="mb-3">Purchases</h1>
    
    <ul class="nav nav-tabs nav-fill mb-3">
        <li class="nav-item">
            <a class="nav-link <?php if(!array_key_exists($state, \App\Purchase::$states)): ?> active <?php endif; ?>" href="<?php echo e(route('profile.purchases')); ?>">
                All (<?php echo e(auth() -> user() -> purchasesCount()); ?>)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($state == 'purchased'): ?> active <?php endif; ?>" href="<?php echo e(route('profile.purchases', 'purchased')); ?>">
                Purchased (<?php echo e(auth() -> user() -> purchasesCount('purchased')); ?>)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($state == 'sent'): ?> active <?php endif; ?>" href="<?php echo e(route('profile.purchases', 'sent')); ?>">
                Sent (<?php echo e(auth() -> user() -> purchasesCount('sent')); ?>)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($state == 'delivered'): ?> active <?php endif; ?>" href="<?php echo e(route('profile.purchases', 'delivered')); ?>">
                Delivered (<?php echo e(auth() -> user() -> purchasesCount('delivered')); ?>)
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if($state == 'disputed'): ?> active <?php endif; ?>" href="<?php echo e(route('profile.purchases', 'disputed')); ?>">
                Disputed (<?php echo e(auth() -> user() -> purchasesCount('disputed')); ?>)
            </a>
        </li>
    </ul>
    
    <table class="table table-hover table-striped">
        <thead>
        <tr>
            <th>Product</th>
            <th>#</th>
            <th>Price</th>
            <th>Shipping</th>
            <th>Total</th>

            <th>Address</th>
            <th>ID</th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('product.show', $purchase -> offer -> product)); ?>"><?php echo e($purchase -> offer -> product -> name); ?></a>
                    <br>by
                    <a href="<?php echo e(route('vendor.show', $purchase -> vendor)); ?>"><?php echo e($purchase -> vendor -> user -> username); ?></a>
                    <?php if($purchase -> isDisputed() && $purchase -> dispute -> isResolved()): ?>
                        <span class="badge badge-success">resolved</span>
                    <?php endif; ?>
                </td>
                <td class="">
                    <?php echo e($purchase -> quantity); ?>

                </td>
                <td class="">
                    <span class="badge badge-mblue"><?php echo $__env->make('includes.currency', ['usdValue' => $purchase -> offer -> price ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></span>
                </td>
                <td class="">
                    <?php if($purchase -> shipping): ?>
                        <p class="text-muted text-sm-center"><?php echo e($purchase -> shipping -> name); ?> - <?php echo e($purchase -> shipping -> price); ?> $</p>
                    <?php else: ?>
                        <span class="badge badge-info">Digital delivery</span>
                    <?php endif; ?>
                </td>
                <td class="">
                    <span class="badge badge-mblue"><?php echo $__env->make('includes.currency', ['usdValue' => $purchase -> value_sum ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></span>
                </td>

                <td>
                    <input type="text" readonly="readonly" class="form-control form-control-sm" value="<?php echo e($purchase -> address); ?>">
                </td>
                <td class="text-right">
                    <a href="<?php echo e(route('profile.purchases.single', $purchase)); ?>" class="btn btn-sm <?php echo e($purchase -> isCanceled() ? 'btn-danger' : 'btn-mblue'); ?> mt-1"
                         ><?php if($purchase->isCanceled()): ?> <em>Canceled</em> <?php else: ?> <?php echo e($purchase -> short_id); ?> <?php endif; ?></a>


                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($purchases -> links('includes.paginate')); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>