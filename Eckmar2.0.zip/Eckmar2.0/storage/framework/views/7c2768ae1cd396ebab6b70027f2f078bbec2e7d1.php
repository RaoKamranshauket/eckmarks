<?php $__env->startSection('title','Vendor - ' . $vendor -> username ); ?>

<?php $__env->startSection('content'); ?>
    
    <nav class="main-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb">

            <li class="breadcrumb-item" aria-current="page"><?php echo e(config('app.name')); ?></li>
            <li class="breadcrumb-item" aria-current="page">Vendor</li>
            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('vendor.show',['user'=>$vendor])); ?>"><?php echo e($vendor -> username); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Feedback</li>
        </ol>
    </nav>


    <div class="row">
        <div class="col">
            <h4> Feedback profile - <?php echo e($vendor->username); ?></h4>
            <?php if($vendor->vendor->isTrusted()): ?>
                <p class="badge badge-success">Trusted vendor <span class="fa fa-check-circle"></span></p>
            <?php endif; ?>
            <?php if($vendor->vendor->isDwc()): ?>
                <p class="badge badge-danger">Deal with caution <span class="fa fa-exclamation-circle"></span></p>
            <?php endif; ?>
            <hr>
        </div>
    </div>

    <?php echo $__env->make('vendor.feedback.stats', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('vendor.feedback.detailed', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>