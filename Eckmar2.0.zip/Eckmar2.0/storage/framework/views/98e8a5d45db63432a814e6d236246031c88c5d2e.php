<?php if($product->featured == 0): ?>
    <a href="<?php echo e(route('admin.product.markfeatured', $product)); ?>" class="btn btn-outline-warning">
        <i class="fas fa-star"></i>
    </a>
<?php else: ?>
    <a href="<?php echo e(route('admin.featuredproducts.show')); ?>" class="btn btn-outline-warning active">
        <i class="fas fa-star"></i>
    </a>
<?php endif; ?>