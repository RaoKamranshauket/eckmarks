<div class="row">
    <div class="col-10">
        <h4>Items for sale <a href="<?php echo e(route('search',['user'=>$vendor->username])); ?>" class="ml-2" style="font-size: 0.9em; text-decoration: none;">(<?php echo e($vendor->products()->count()); ?>)</a></h4>
    </div>
    <div class="col-2 text-md-right">
        <a href="<?php echo e(route('search',['user'=>$vendor->username])); ?>">See all items</a>
    </div>
</div>

<div class="row mt-2">
    <?php $__currentLoopData = $vendor->recentProducts(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 col-sm-6 mb-2">
            <?php echo $__env->make('includes.product.card',$product, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>