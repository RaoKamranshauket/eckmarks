<?php $__env->startSection('title','Vendor - ' . $vendor -> username ); ?>

<?php $__env->startSection('content'); ?>
    
    <nav class="main-breadcrumb" aria-label="breadcrumb">
        <ol class="breadcrumb">

            <li class="breadcrumb-item" aria-current="page"><?php echo e(config('app.name')); ?></li>
            <li class="breadcrumb-item" aria-current="page">Vendor</li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($vendor -> username); ?></li>
        </ol>
    </nav>



    <div class="row">
        <div class="col-md-12 profile-bg <?php echo e($vendor->vendor->getProfileBg()); ?> rounded pt-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php echo $__env->make('includes.vendor.card', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('includes.vendor.stats', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('vendor-content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>