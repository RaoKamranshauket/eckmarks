<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.validation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <h1 class="my-3">Private Messages</h1>
    <hr>
    <div class="row justify-content-center">
        <div class="col-md-4">

            <a href="<?php echo e(route("profile.messages")); ?>">
                <h3 class="mb-3">Conversations</h3>
            </a>
            <hr>

            <?php if(auth() -> user() -> conversations -> isNotEmpty()): ?>
                <div class="list-group">
                    <a href="<?php echo e(route("profile.messages")); ?>" class="list-group-item list-group-item-action <?php if(!$conversation): ?> bg-info text-white <?php endif; ?>">
                        <i class="fas fa-user-plus"></i>
                        New Conversation
                    </a>
                    <?php $__currentLoopData = $usersConversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversationItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('profile.messages', $conversationItem)); ?>"
                           class="list-group-item d-flex justify-content-between list-group-item-action <?php if($conversationItem  == $conversation): ?> active <?php endif; ?>">

                            <?php if($conversationItem -> otherUser() -> exists): ?>
                                <?php echo e($conversationItem -> otherUser() -> username); ?>

                            <?php else: ?>
                                <em><?php echo e($conversationItem -> otherUser() -> username); ?></em>
                            <?php endif; ?>
                            <?php if($conversationItem -> unreadMessages() > 0): ?>
                                <span class="badge d-flex align-items-center badge-warning badge-pill"><?php echo e($conversationItem -> unreadMessages()); ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route("profile.messages.conversations.list")); ?>" class="list-group-item list-group-item-action list-group-item-indigo <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'profile.messages.conversations.list')): ?> bg-info text-white <?php endif; ?>">
                        <i class="fas fa-list"></i>
                        All Conversations
                    </a>
                </div>

            <?php else: ?>
                <div class="alert alert-warning text-center">You don't have any conversations!</div>
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <?php if(!$conversation): ?>
                <h3 class="mb-3">New conversation</h3>
                <hr>
                <form action="<?php echo e(route('profile.messages.conversation.new')); ?>" method="POST" class="my-2">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" id="username" name="username" placeholder="Username of the receiver..."
                           class="form-control my-2 w-100" value="<?php echo e($new_conversation_other_party); ?>">
                    <textarea name="message" class="form-control my-2" rows="5"
                              placeholder="New message here"></textarea>
                    <button type="submit" class="btn btn-primary btn-block">Send message</button>
                </form>
            <?php else: ?>
                <h3 class="mb-3">Conversation with <em><?php echo e($conversation -> otherUser() -> username); ?></em></h3>
                

                <?php if($conversation -> otherUser() -> exists): ?>
                <form action="<?php echo e(route('profile.messages.message.new', $conversation)); ?>" method="POST">
                    <textarea class="form-control" rows="5" name="message"
                              placeholder="Place you message here, encrypted messages are welcome!"></textarea>
                    <button type="submit" class="btn btn-primary ml-auto mt-2 d-block">Send message</button>
                    <?php echo e(csrf_field()); ?>

                </form>
                <?php endif; ?>

                <?php if($conversation -> messages -> isEmpty()): ?>
                    <div class="alert alert-warning my-2">There is no messages in this conversation!</div>
                <?php else: ?>
                    <?php $__currentLoopData = $conversationMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card my-2">
                            <div class="card-body">
                                <?php if($message -> isEncrypted()): ?>
                                    <textarea readonly class="form-control"
                                              rows="5"><?php echo e($message -> getContent()); ?></textarea>
                                <?php else: ?>
                                    <p class="card-text"><?php echo e($message -> getContent()); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer text-right">
                                <small class="text-muted">by
                                    <strong><?php echo e($message -> getSender() -> username); ?></strong>, <?php echo e($message -> timeAgo()); ?>

                                </small>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($conversationMessages -> links('includes.paginate')); ?>

                <?php endif; ?>
            <?php endif; ?>
        </div>

    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>