<?php $__env->startSection('product-content'); ?>

    <?php if($product -> hasFeedback()): ?>
        <h3 class="mb-3">Feedback (<?php echo e(count($product -> feedback)); ?>)</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Quality rate (<?php echo e($product -> avgRate('quality_rate')); ?>)</th>
                    <th>Communication rate (<?php echo e($product -> avgRate('communication_rate')); ?>)</th>
                    <th>Shipping rate (<?php echo e($product -> avgRate('shipping_rate')); ?>)</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $product -> feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo $__env->make('includes.purchases.stars', ['stars' => $feedback -> quality_rate], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </td>
                        <td>
                            <?php echo $__env->make('includes.purchases.stars', ['stars' => $feedback -> communication_rate], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </td>
                        <td>
                            <?php echo $__env->make('includes.purchases.stars', ['stars' => $feedback -> shipping_rate], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </td>
                        <td>
                            <?php echo e($feedback -> comment); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    <?php else: ?>
        <div class="alert alert-warning">There is no available feedback for this product, yet.</div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>