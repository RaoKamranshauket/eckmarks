<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="category">
        <a href="<?php echo e(route('category.show', $cat)); ?>" class="list-group-item category <?php if(isset($category) && $cat -> isAncestorOf(optional($category))): ?> active <?php endif; ?>  align-items-center rounded-0 list-group-item-action d-flex justify-content-between">
            <?php echo e($cat -> name); ?>

            <span class="badge badge-warning badge-pill"><?php echo e($cat -> num_products); ?></span>
        </a>
        <?php if($cat -> children -> isNotEmpty()): ?>
            <div class="pl-3 subcategories">
                <?php echo $__env->make('includes.subcategories', ['categories' => $cat -> children], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>