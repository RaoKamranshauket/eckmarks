<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <h2 class="mb-3">Cart (<?php echo e($numberOfItems); ?>)</h2>
        </div>
        <div class="col-md-4 text-right">
            <a href="<?php echo e(route('profile.cart.clear')); ?>" class="btn btn-lg btn-danger">
                <i class="fas fa-trash-alt mr-2"></i>
                Clear
            </a>
        </div>
        <div class="col-md-12">
            <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="form-row bg-dark text-white text-center rounded py-2">
                <div class="col-md-2 justify-content-center">
                    Product name
                </div>
                <div class="col-md-1 justify-content-center">
                    <?php echo e(\App\Marketplace\Utility\CurrencyConverter::getSymbol(\App\Marketplace\Utility\CurrencyConverter::getLocalCurrency())); ?> per item
                </div>
                <div class="col-md-1">
                    Coin
                </div>
                <div class="col-md-1 justify-content-center">
                    Amount
                </div>
                <div class="col-md-2 justify-content-center">
                    Delivery/Payment
                </div>

                <div class="col-md-3 justify-content-center">
                    Message
                </div>
            </div>

        </div>
        <?php if(!empty($items)): ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12  my-1 py-2">
            <form action="<?php echo e(route('profile.cart.add', \App\Product::find($productId))); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-row bg-light">
                    <div class="col-md-2">
                        <a href="<?php echo e(route('product.show', $item -> offer -> product)); ?>">
                            <h4><?php echo e($item -> offer -> product -> name); ?></h4>
                        </a>
                        by
                        <a class="badge badge-info" href="<?php echo e(route('vendor.show', $item -> offer -> product -> user)); ?>">
                            <?php echo e($item -> vendor -> user -> username); ?>

                        </a>
                    </div>
                    <div class="col-md-1 d-flex align-items-center">
                        <h5 class="text-center w-100">
                            <span class="badge badge-info">
                                <?php echo $__env->make('includes.currency', ['usdValue' => $item -> offer -> price], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </span>
                        </h5>
                    </div>
                    <div class="col-md-1  d-flex align-items-center justify-content-center">
                        <?php if(count($item -> offer -> product -> getCoins()) > 1): ?>
                        <select name="coin" id="coin" class="form-control form-control-sm">
                            <?php $__currentLoopData = $item -> offer -> product -> getCoins(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($coin); ?>" <?php echo e($coin == $item -> coin_name ? 'selected' : ''); ?> ><?php echo e(strtoupper(\App\Purchase::coinDisplayName($coin))); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php elseif(count($item -> offer -> product -> getCoins()) == 1): ?>
                            <input type="hidden" name="coin" value="<?php echo e($item -> offer -> product -> getCoins()[0]); ?>">
                            <input type="text" value="<?php echo e(strtoupper(\App\Purchase::coinDisplayName($item -> offer -> product -> getCoins()[0]))); ?>" class="form-control form-control-sm disabled" disabled>
                        <?php endif; ?>


                    </div>
                    <div class="col-md-1 d-flex align-items-center">
                        <input type="number" class="form-control form-control-sm" name="amount" id="amount" min="1" max="<?php echo e($item -> offer -> product -> quantity); ?>" placeholder="Quantity" value="<?php echo e($item -> quantity); ?>"/>
                    </div>
                    <div class="col-md-2 text-center">
                        <?php if($item -> offer -> product -> isPhysical()): ?>
                        <select name="delivery" id="delivery" class="form-control form-control-sm">
                            <?php $__currentLoopData = $item -> offer -> product -> specificProduct() -> shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($shipping -> id); ?>" <?php if($shipping -> id == $item -> shipping -> id): ?> selected <?php endif; ?>><?php echo e($shipping -> long_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php else: ?>
                        <span class="badge badge-info">Digital delivery</span>
                        <?php endif; ?>
                            <br>
                        <?php if(count($item -> offer -> product -> getTypes()) > 1): ?>
                        <select name="type" id="type" class="form-control form-control-sm">
                            <?php $__currentLoopData = $item -> offer -> product -> getTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php echo e($type == $item -> type ? 'selected' : ''); ?> ><?php echo e(\App\Purchase::$types[$type]); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php elseif(count($item -> offer -> product -> getTypes()) == 1): ?>
                            <input type="hidden" name="type" value="<?php echo e($item -> offer -> product -> getTypes()[0]); ?>">
                            <input type="text" value="<?php echo e(\App\Purchase::$types[$item -> offer -> product -> getTypes()[0]]); ?>" class="form-control form-control-sm disabled" disabled>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-3 d-flex align-items-stretch">
                        <textarea name="message" id="message" rows="3" placeholder="Message will be encrypted with vendor's PGP key. Click on edit to save message!" style="resize: 0" class="form-control form-control-sm"><?php echo e($item -> message); ?></textarea><br>
                    </div>
                    <div class="col-md-2 d-flex align-items-center justify-content-around">
                        <button type="submit" class="btn btn-outline-primary">
                            <i class="far fa-edit mr-2"></i>
                            Edit
                        </button>
                        <a href="<?php echo e(route('profile.cart.remove', $productId)); ?>" class="btn btn-outline-danger">
                            <i class="fas fa-minus-circle"></i>
                        </a>
                    </div>
                </div>

            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-md-12 my-3">
                <div class="alert alert-warning">There are no items in cart!</div>
            </div>
        <?php endif; ?>

        <div class="col-md-12 py-2 justify-content-end">
            <div class="row">
                <div class="col-md-6">
                    <h4 class="m-0">Total sum: <?php echo $__env->make('includes.currency', ['usdValue' => $totalSum], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></h4>
                </div>
                <div class="col-md-6 text-right">
                    <a href="<?php echo e(route('profile.cart.checkout')); ?>" class="btn ml-auto btn-lg btn-mblue">
                        <i class="fas fa-cart-arrow-down mr-2"></i>
                        Checkout
                    </a>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>