<?php if(session()->has('errormessage')): ?>
    <div id="error" class="alert alert-danger text-center">
        <?php echo e(session()->get('errormessage')); ?>

    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div id="error" class="alert alert-danger text-center">
        <?php echo e(session()->get('error')); ?>

    </div>
<?php endif; ?>
