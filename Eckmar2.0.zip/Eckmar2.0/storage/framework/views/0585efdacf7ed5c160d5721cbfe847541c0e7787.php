<?php $__env->startSection('admin-content'); ?>

    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.validation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h3 class="mb-5">Message to everyone</h3>
    <hr>
    <form action="<?php echo e(route('admin.messages.send')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-row">
            <div class="col-md-12 mb-2">
                <label for="message">
                    Message:
                </label>
                <textarea name="message" placeholder="Paste your message here." id="message" class="form-control" rows="7"></textarea>
            </div>
            <div class="col-md-6">
                <label>Groups:</label>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="admins" id="admins" name="groups[]">
                    <label class="form-check-label" for="admins">
                        Admins
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="vendors" id="vendors" name="groups[]">
                    <label class="form-check-label" for="vendors">
                        Vendors
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="buyers" id="buyers" name="groups[]">
                    <label class="form-check-label" for="buyers">
                        Buyers
                    </label>
                </div>
            </div>
            <div class="col-md-6 justify-content-lg-end d-flex">
                <button type="submit" class="btn btn-outline-primary mt-auto">Send messages</button>
            </div>
        </div>


    </form>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>