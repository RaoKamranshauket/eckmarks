<?php $__env->startSection('profile-content'); ?>

    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1 class="mt-5 mb-3">Confirm your PGP key:</h1>
    <hr>
    <div class="form-group">
        <label for="decrypt_message">Decrypt this message:</label>
        <textarea name="decrypt_message" id="decrypt_message" class="form-control " rows="10" style="resize: none;"  readonly><?php echo e(session() -> get(\App\Marketplace\PGP::NEW_PGP_ENCRYPTED_MESSAGE)); ?></textarea>
        <p class="text-muted">Decrypt this message and get validation number.</p>
    </div>
    <form method="POST" action="<?php echo e(route('profile.pgp.store')); ?>" class="form-inline">
        <?php echo e(csrf_field()); ?>

        <label for="validation_number">Validation number:</label>
        <input type="number" class="form-control mx-2" required name="validation_number" id="validation_number"/>
        <button class="btn btn-outline-success">Validate PGP</button>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>