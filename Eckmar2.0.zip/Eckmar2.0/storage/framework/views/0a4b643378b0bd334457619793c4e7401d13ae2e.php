<?php $__env->startSection('vendor-content'); ?>

    <?php echo $__env->make('includes.vendor.products', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>