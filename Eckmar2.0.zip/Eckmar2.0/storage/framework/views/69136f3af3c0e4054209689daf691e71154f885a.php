<?php $__env->startSection('product-content'); ?>


    <p><?php echo \GrahamCampbell\Markdown\Facades\Markdown::convertToHtml(nl2br(e($product -> rules))); ?></p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>