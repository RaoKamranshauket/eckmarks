<?php $__env->startSection('product-title', 'Edit product - '. $basicProduct -> name); ?>

<?php $__env->startSection('product-basic-form'); ?>
    <?php echo $__env->make('includes.profile.basicform', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.product.edit', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>