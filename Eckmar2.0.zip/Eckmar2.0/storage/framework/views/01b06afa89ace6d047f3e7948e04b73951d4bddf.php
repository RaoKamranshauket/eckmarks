<?php $__env->startSection('title', 'Wishlist'); ?>

<?php $__env->startSection('profile-content'); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <h1 class="mb-3">Wishlist</h1>
    <hr>

    <?php if(auth() -> user() -> whishes -> isNotEmpty()): ?>
        <div class="card-columns">
            <?php $__currentLoopData = auth() -> user() -> whishes() ->orderByDesc('created_at') -> get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('includes.product.card', ['product' => $whish -> product], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">Your wishlist of products is empty!</div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>