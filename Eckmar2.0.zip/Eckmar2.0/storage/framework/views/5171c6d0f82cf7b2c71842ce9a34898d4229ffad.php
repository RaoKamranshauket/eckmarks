<div class="row mt-3">
    <table class="table">
        <thead>
            <th>
                Feedback
            </th>
            <th>
                From
            </th>
            <th>
                When
            </th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <span><?php echo $__env->make('includes.vendor.feedback_icon',$fb, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?><?php echo e($fb->comment); ?></span><?php if($fb->isLowValue()): ?> <span class="badge badge-warning">Low value</span> <?php endif; ?><br>
                        <span class="text-muted"><?php echo e($fb->product_name); ?></span>
                    </td>
                    <td>
                        <span>Buyer: <?php echo e($fb->getHiddenBuyerName()); ?></span><br>
                        <span class="text-muted">US $<?php echo e($fb->product_value); ?></span>
                    </td>
                    <td>
                        <?php echo e($fb->getLeftTime()); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($feedback->links()); ?>

</div>