<?php $__env->startSection('admin-content'); ?>
    <div class="row">
        <div class="col">
            <h4>
                Activity log of all administrators
            </h4>
            <hr>
            <p class="small text-muted">
                New logs are loaded  <?php if($cacheMinutes == 0): ?> instantly <?php else: ?> every <?php echo e($cacheMinutes); ?> <?php echo e(str_plural('minute',$cacheMinutes)); ?> <?php endif; ?>. You can change this option in configuration.
            </p>
        </div>
    </div>

    <table class="table">
        <thead>
        <tr>
            <th>User</th>
            <th>Type</th>
            <th>Description</th>
            <th>Performed on</th>
            <th>Time</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.users.view',$log->user->id)); ?>"><?php echo e($log->user->username); ?></a></td>
                    <td><?php echo e($log->type); ?></td>
                    <td><?php echo e($log->description); ?></td>
                    <td><a href="<?php echo e($log->performedOn()['link']); ?>"><?php echo e($log->performedOn()['text']); ?></a></td>
                    <td><?php echo e($log->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="row">
        <div class="col-md-6 offset-md-3">
            <div class="text-center">
                <?php echo e($logs->links()); ?>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>