<?php $__env->startSection('profile-content'); ?>


    <h1 class="my-3">Bitmessage</h1>
    <hr>
    <p class="my-3">Service to forward all your notifications from marketplace to your Bitmessage address</p>
    <p>Service staus: <?php if($enabled): ?> <span class="badge badge-success">Enabled</span> <?php else: ?> <span class="badge badge-danger">Disabled</span> <?php endif; ?></p>


    <?php if($user->bitmessage_address !== null): ?>
    <div class="alert <?php if($enabled): ?> alert-info <?php else: ?> alert-warning <?php endif; ?>">You have configured your Bitmessage address,<?php if($enabled): ?> notifications will be forwareded <?php else: ?> however service is not currently enabled <?php endif; ?> </div>
    <?php else: ?>
        <div class="alert alert-warning">In order to forward notifications please configure your Bitmessage address</div>
    <?php endif; ?>


    <?php if($user->bitmessage_address == null): ?>
        <h4>Add Bitmessage address</h4>
    <?php else: ?>
        <h4>Change Bitmessage address</h4>
        <p class="text-muted">Current address: <?php echo e($user->bitmessage_address); ?></p>
    <?php endif; ?>
    <hr>
    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('profile.bitmessage.sendcode')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="address">Bitmessage address:</label>
            <input type="text" name="address" id="" class="form-control" id="address" value="<?php if(session()->has('bitmessage_confirmation')): ?> <?php echo e(session()->get('bitmessage_confirmation')['address']); ?> <?php endif; ?>">
        </div>
        <div class="form-group">
            <?php if(session()->has('bitmessage_confirmation')): ?>
                <button type="submit" class="btn btn-outline-secondary">Resend confirmation message</button>
                <p class="text-muted">You can request new confirmation message every <?php echo e(config('bitmessage.confirmation_msg_frequency')); ?> <?php echo e(str_plural('second',config('bitmessage.confirmation_msg_frequency'))); ?></p>
            <?php else: ?>
                <button type="submit" class="btn btn-outline-primary">Send confirmation message</button>
            <?php endif; ?>
        </div>
    </form>

    <?php if(session()->has('bitmessage_confirmation')): ?>
        <div class="row">
            <div class="col-md-6">
                <form action="<?php echo e(route('profile.bitmessage.confirmcode')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="code">Confirmation code</label>
                        <input type="text" name="code" id="" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-outline-primary">Confirm address</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>