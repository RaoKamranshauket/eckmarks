<?php $__env->startSection('title','Sign in'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 justify-content-center">
        <div class="col-md-4" style ="width: 450px; border-radius: 15px;">

            <h2>Sign In</h2>
            <br> <div class="image">
                 <img src="/img/logo.png" style="height: 250px;width: 350px;"></img></div>
            <div class="mt-3">
                <form action="<?php echo e(route('auth.signin.post')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <input type="text" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'username',$errors)): ?> is-invalid <?php endif; ?>" placeholder="Username" name="username" id="username">
                        <?php if (\Illuminate\Support\Facades\Blade::check('error', 'username',$errors)): ?>
                            <p class="text-danger"><?php echo e($errors->first('username')); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'password',$errors)): ?> is-invalid <?php endif; ?>" placeholder="Password" name="password"
                               id="password">
                        <?php if (\Illuminate\Support\Facades\Blade::check('error', 'password',$errors)): ?>
                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php echo $__env->make('includes.captcha', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="form-group text-center">
                        <div class="row">
                            <div class="col-xs-12 col-md-4 offset-md-4">
                                <button type="submit" class="btn btn-outline-primary btn-block">Sign In</button>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </form>
            </div>
                <div class="mt-3">
                    Forgot your password?
                    <a href="/forgotpassword" style="text-decoration: none">Reset it here
                    </a>
                </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>