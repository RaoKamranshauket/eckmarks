<nav class="navbar navbar-expand-lg  navbar-dark bg-mgray">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route("home")); ?>"><?php echo e(config('app.name')); ?></a>

        <input type="checkbox" id="navbar-toggle-cbox">


        <label class="navbar-toggler" for="navbar-toggle-cbox" data-toggle="collapse"
               data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
               aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </label>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <ul class="navbar-nav mr-auto">
                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Admin panel</a>
                    </li>
                    <?php endif; ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('moderator')): ?>
                    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'admin')): ?> active <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Moderator panel</a>
                    </li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'profile.tickets')): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('profile.tickets')); ?>">Support</a>
                        </li>
                    <?php endif; ?>

                </ul>

                <ul class="navbar-nav">
                    <?php if(auth()->guard()->check()): ?>

                        <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'profile.notifications')): ?> active <?php endif; ?>">
                            <a href="<?php echo e(route('profile.notifications')); ?>" class="nav-link">
                                <span <?php if(auth()->user()->unreadNotifications()->count() > 0): ?> class="text-warning" <?php endif; ?>><i class="fa fa-bell"></i> <?php echo e(auth()->user()->unreadNotifications()->count()); ?></span>
                            </a>
                        </li>
                        <li class="nav-item text-center <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'profile.cart')): ?> active <?php endif; ?>">
                            <a class="nav-link w-100 text-black-50 <?php echo e(\App\Marketplace\Cart::getCart() ->numberOfItems() == 0 ? 'bg-secondary' : 'bg-warning'); ?>" href="<?php echo e(route('profile.cart')); ?>">
                                <i class="fas fa-shopping-cart mr-2"></i>
                                (<?php echo e(session('cart_items') !== null ? count(session('cart_items')) : 0); ?>)
                            </a>
                        </li>

                        <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('isroute', 'profile.index')): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('profile.index')); ?>"><?php echo e(auth()->user()->username); ?></a>
                        </li>

                        <form class="form-inline" action="<?php echo e(route('auth.signout.post')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-link text-muted my-0" type="submit" style="text-decoration: none;">Sign Out</button>
                        </form>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('auth.signin')); ?>">Sign In</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('auth.signup')); ?>">Sign Up</a>
                        </li>
                    <?php endif; ?>
                </ul>

        </div>
    </div>
</nav>

