<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/app.css">


    <?php if (! empty(trim($__env->yieldContent('title')))): ?>
        <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <?php else: ?>
        <title><?php echo e(config('app.name')); ?></title>
    <?php endif; ?>

</head>
<body class="pb-4">
<?php echo $__env->make('master.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if (! empty(trim($__env->yieldContent('container-fluid')))): ?>
    <div class="container-fluid">
<?php else: ?>
    <div class="container">
<?php endif; ?>
        <?php echo $__env->make('includes.jswarning', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="mt-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>


</div>

</body>
</html>