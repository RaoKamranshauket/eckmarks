<?php $__env->startSection('form-content'); ?>
<?php if(optional($productsOffers) -> isNotEmpty()): ?>
    <table class="table table-striped table-hover ">
    <thead>
        <tr>
        <th scope="col">Price (<?php echo e(\App\Marketplace\Utility\CurrencyConverter::getLocalSymbol()); ?>)</th>
        <th scope="col">Minimum quantity</th>
        <th scope="col"></th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productsOffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($offer -> local_price); ?></th>
                <td><?php echo e($offer -> min_quantity); ?></td>
                <td class="text-right">
                    <a href="<?php echo e(route('profile.vendor.product.offers.remove', [ $offer -> min_quantity, $basicProduct])); ?>" class="btn btn-sm btn-outline-danger">Remove</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
<?php else: ?>
    <div class="alert alert-warning">You don't have any offer please add at least one!</div>
<?php endif; ?>

<h3 class="mt-3">Add offer</h3>
<hr>
<form method="POST" action="<?php echo e(route('profile.vendor.product.offers.add', $basicProduct)); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-row">
        <div class="col">
            <input type="number" step=".01" min="0.01" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'price', $errors)): ?> is-invalid <?php endif; ?>" name="price" value="<?php echo e(old('min_quantity')); ?>" placeholder="Price in <?php echo e(\App\Marketplace\Utility\CurrencyConverter::getLocalSymbol()); ?>">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'price', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('price')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col">
            <input type="min_quantity" step="1" min="1" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'min_quantity', $errors)): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('min_quantity')); ?>" name="min_quantity" placeholder="Minimum quantity for this price">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'price', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('price')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col">
            <button class="btn btn-outline-success" type="submit"><i class="fas fa-plus mr-2"></i> Add offer</button>
        </div>
    </div>
</form>

<div class="col-md-12 text-center mt-3">
    <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
        <a href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, $basicProduct -> afterOffers()])); ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i>  Next</a>
    <?php elseif(request() -> is('admin/product/*')): ?>
        <a href="<?php echo e(route('admin.product.edit', [$basicProduct, $basicProduct -> afterOffers()])); ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i>  Next</a>
    <?php else: ?>
        <a href="<?php echo e(route('profile.vendor.product.' . ( session('product_type') == 'physical' ? 'delivery' : 'digital' ) )); ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i>  Next</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.profile.addingform', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>