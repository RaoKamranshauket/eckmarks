<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <h1 class="mb-3">Support</h1>
            <hr>
            <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-md-3">
            <h3 class="mb-2">Tickets</h3>

            <a href="<?php echo e(route('profile.tickets')); ?>" class="btn btn-block <?php if($ticket): ?> btn-outline-primary <?php else: ?> btn-primary <?php endif; ?> my-2">
                <i class="fas fa-plus-circle mr-2"></i>
                New ticket
            </a>

            <?php if(auth() -> user() -> tickets() -> exists()): ?>
                <div class="list-group flex-md-column flex-row nav-pills justify-content-sm-center">
                <?php $__currentLoopData = auth() -> user() -> tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currTicket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('profile.tickets', $currTicket)); ?>" class="list-group-item list-group-item-action <?php if($currTicket == $ticket): ?> active <?php endif; ?>">
                        <?php echo e($currTicket -> title); ?>

                        <?php if($currTicket -> solved): ?>
                            <span class="badge badge-success">Solved</span>
                        <?php else: ?>
                            <?php if($currTicket -> answered): ?>
                                <span class="badge badge-warning">Answered</span>
                            <?php endif; ?>
                        <?php endif; ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">
                    Your ticket list is empty!
                </div>
            <?php endif; ?>

        </div>
        <div class="col-md-9">
            <?php if($ticket): ?>
                <?php echo $__env->make('includes.profile.ticket', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('includes.profile.newticket', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>