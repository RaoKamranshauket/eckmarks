<div class="card">
    <img class="card-img-top" src="<?php echo e(asset('storage/'  . $product -> frontImage() -> image)); ?>" alt="<?php echo e($product -> name); ?>">
    <div class="card-body">
        <a href="<?php echo e(route('product.show', $product)); ?>"><h4 class="card-title"><?php echo e($product -> name); ?></h4></a>
        <p class="card-subtitle">From: <strong><?php echo e($product->getLocalPriceFrom()); ?> <?php echo e(\App\Marketplace\Utility\CurrencyConverter::getLocalSymbol()); ?></strong>  - <?php echo e($product -> category -> name); ?> - <span class="badge badge-info"><?php echo e($product -> type); ?></span></p>
        <p class="card-text">
            Posted by <a href="<?php echo e(route('vendor.show', $product -> user)); ?>" class="badge badge-info"><?php echo e($product -> user -> username); ?></a>, <strong><?php echo e($product -> quantity); ?></strong> left
        </p>
        <a href="<?php echo e(route('product.show', $product)); ?>" class="btn btn-primary d-block">Buy now</a>
    </div>
</div>