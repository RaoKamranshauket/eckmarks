<?php $__env->startSection('form-content'); ?>
    <?php if(!empty($productsShipping)): ?>
    <table class="table table-striped table-hover">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Price(<?php echo e(\App\Marketplace\Utility\CurrencyConverter::getLocalSymbol()); ?>)</th>
            <th scope="col">Duration</th>
            <th scope="col">Minimum quantity</th>
            <th scope="col">Maximum quantity</th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
        <?php
            $i = 0;
        ?>
        <?php $__currentLoopData = $productsShipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($shipping -> name); ?></th>
                <th><?php echo e($shipping -> local_value); ?></th>
                <td><?php echo e($shipping -> duration); ?></td>
                <td><?php echo e($shipping -> from_quantity); ?></td>
                <td><?php echo e($shipping -> to_quantity); ?></td>
                <td class="text-right">
                    <?php if($shipping -> exists): ?>
                        <a href="<?php echo e(route('profile.vendor.product.delivery.remove', [$shipping -> id, $physicalProduct] )); ?>" class="btn btn-sm btn-outline-danger">Remove</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('profile.vendor.product.delivery.remove', $i)); ?>" class="btn btn-sm btn-outline-danger">Remove</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php
                $i++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="alert alert-warning">You don't have any offer please add at least one!</div>
<?php endif; ?>

<h3 class="mt-3">Add delivery option</h3>
<hr>
<form method="POST" action="<?php echo e(route('profile.vendor.product.delivery.new', $physicalProduct -> product)); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-row">
        <div class="col-md-4 my-2">
            <input type="text" maxlength="10" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('name')); ?>" name="name" placeholder="Name">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'name', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('name')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4 my-2">
            <input type="number" step=".01" min="0.01" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'price', $errors)): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('price')); ?>" name="price" placeholder="Price in <?php echo e(\App\Marketplace\Utility\CurrencyConverter::getLocalSymbol()); ?>(Ex. 15.99)">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'price', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('price')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4 my-2">
            <input type="text" maxlength="30" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'duration', $errors)): ?> is-invalid <?php endif; ?>" name="duration" value="<?php echo e(old('duration')); ?>" placeholder="Duration(Ex. 1-2 weeks)">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'duration', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('duration')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4 my-2">
            <input type="number" step="1" min="1" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'from_quantity', $errors)): ?> is-invalid <?php endif; ?>" name="from_quantity" value="<?php echo e(old('from_quantity')); ?>" placeholder="Minimum quantity for this delivery">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'from_quantity', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('from_quantity')); ?>

            </div>
            <?php endif; ?>
        </div>
       <div class="col-md-4 my-2">
            <input type="number" step="1" min="1" class="form-control <?php if (\Illuminate\Support\Facades\Blade::check('error', 'to_quantity', $errors)): ?> is-invalid <?php endif; ?>" name="to_quantity" value="<?php echo e(old('to_quantity')); ?>" placeholder="Maximum quantity for this delivery">
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'to_quantity', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('to_quantity')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4 my-2 text-right">
            <button class="btn btn-outline-success" type="submit"><i class="fas fa-plus mr-2"></i> Add shipping</button>
        </div>
    </div>
</form>

<h3 class="mt-3">Shipping countries</h3>
<hr>
<form method="POST" action="<?php echo e(route('profile.vendor.product.delivery.options', $physicalProduct)); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-row">
        <div class="col-md-4 my-2">
            <label for="countries_option">Ships to</label>
            <select class="form-control" name="countries_option" id="countries_option">
                <?php $__currentLoopData = \App\PhysicalProduct::$countriesOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $short => $optionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($short); ?>" <?php if($short == $physicalProduct -> countries_option): ?> selected <?php endif; ?>><?php echo e($optionName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>


            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'countries_option', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('name')); ?>

            </div>
            <?php endif; ?>

        </div>
        <div class="col-md-4 my-2">
            <label for="countries">Included/excluded countries:</label>
            <select class="form-control " name="countries[]" multiple>
                <?php $__currentLoopData = config('countries'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryShort => $countryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($countryShort); ?>" <?php if(in_array($countryShort, $physicalProduct-> countriesArray())): ?> selected <?php endif; ?>><?php echo e($countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'countries', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('countries')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-4 my-2">
            <label for="country_from">Country from:</label>
            <select class="form-control " name="country_from">
                <?php $__currentLoopData = config('countries'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countryShort => $countryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($countryShort); ?>" <?php if($countryShort == $physicalProduct-> country_from): ?> selected <?php endif; ?>><?php echo e($countryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if (\Illuminate\Support\Facades\Blade::check('error', 'country_from', $errors)): ?>
            <div class="invalid-feedback">
                <?php echo e($errors -> first('country_from')); ?>

            </div>
            <?php endif; ?>
        </div>


    </div>
    <div class="form-row justify-content-center">
        <div class="col-md-3 text-center">

            <?php if(request() -> is('profile/vendor/product/edit/*')): ?>
                <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                <a href="<?php echo e(route('profile.vendor.product.edit', [$basicProduct, 'images'])); ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
            <?php elseif(request() -> is('admin/product/*')): ?>
                <button class="btn btn-outline-success" type="submit"><i class="far fa-save mr-2"></i> Save</button>
                <a href="<?php echo e(route('admin.product.edit', [$basicProduct, 'images'])); ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-down mr-2"></i> Next</a>
            <?php else: ?>
                <button class="btn btn-outline-primary" type="submit"><i class="fas fa-chevron-down mr-2"></i>  Next</button>
            <?php endif; ?>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.profile.addingform', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>