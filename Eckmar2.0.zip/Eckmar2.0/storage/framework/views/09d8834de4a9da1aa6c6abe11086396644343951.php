<?php $__env->startSection('title','Error hapend'); ?>

<?php $__env->startSection('content'); ?>


    <div class="text-center">
        <h1 class="text-danger my-3">404 Page not found</h1>
        <p class="display-4">This is not the page you are looking for!</p>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>