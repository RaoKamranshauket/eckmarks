<h1 class="mb-3">Featured products</h1>
<hr>


<div class="row">
    <div class="col">
        <?php echo $__env->make('includes.flash.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.flash.success', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.flash.invalid', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>

<table class="table">
    <thead>
    <tr>
        <th>Title</th>
        <th>Category</th>
        <th>Price (best)</th>
        <th>Type</th>
        <th>Vendor</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <form action="<?php echo e(route('admin.featuredproducts.remove')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <?php if($products->count() == 0 ): ?>
            <tr>
                <td colspan="6" class="text-center">
                    <h4 class="mt-5">No products found</h4>
                </td>
            </tr>
        <?php else: ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <strong><?php echo e($product->name); ?></strong>
                    </td>
                    <td>
                        <?php echo e($product->category->name); ?>

                    </td>
                    <td>
                        <?php echo $__env->make('includes.currency', ['usdValue' => $product->price_from], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <span class="badge badge-info"><?php echo e($product->type); ?></span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.users.view',['user'=>$product->user->id])); ?>"><?php echo e($product->user->username); ?></a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.product.edit', $product -> id)); ?>" class="btn btn-outline-mblue">
                            <i class="fas fa-pen-square"></i>
                        </a>
                        <button type="submit" value="<?php echo e($product->id); ?>" name="product_id"
                                class="btn btn-outline-warning">
                            <i class="fas fa-backspace"></i> Remove from featured
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </form>

    </tbody>
</table>

<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="text-center">
            <?php echo e($products->links()); ?>

        </div>
    </div>
</div>
