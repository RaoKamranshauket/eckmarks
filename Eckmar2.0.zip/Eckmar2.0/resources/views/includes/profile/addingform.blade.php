<div class="collapse show">
    <div class="card-body">
        @yield('form-content')
    </div>
</div>