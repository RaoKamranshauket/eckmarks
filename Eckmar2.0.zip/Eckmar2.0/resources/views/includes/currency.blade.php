{{ \App\Marketplace\Utility\CurrencyConverter::convertToLocal($usdValue) }}
{{ \App\Marketplace\Utility\CurrencyConverter::getSymbol(\App\Marketplace\Utility\CurrencyConverter::getLocalCurrency()) }}